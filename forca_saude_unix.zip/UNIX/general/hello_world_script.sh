#!/usr/bin/env bash
# Um script simples

echo "Hello World"
